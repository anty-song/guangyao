document.writeln("    <a class='kefu' href='#'>");
document.writeln("    	<img src='images/kefu.png' alt='聊多多'>");
document.writeln("    </a>");
document.writeln("    <footer>");
document.writeln("      <p class='saying hidden-xs'>你会想我的对吧</p>");
document.writeln("      <p class='address'>(c)2016-2025 liaoduoduo18 All Rights Reserved 北京市昌平区回龙观镇科星西路106号院6号楼</p>");
document.writeln("    </footer>");