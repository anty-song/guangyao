export const ENDED = 'ended'
export const LIVE = 'live'
export const CONCERN = 'concern'
